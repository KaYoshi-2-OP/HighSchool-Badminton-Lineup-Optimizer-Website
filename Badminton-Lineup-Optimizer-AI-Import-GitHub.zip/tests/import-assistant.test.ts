import assert from "node:assert/strict";
import test from "node:test";
import {
  normalizeImportDate,
  validateMatchRows,
  validateRosterRows,
} from "../lib/import-assistant.ts";

test("normalizes unambiguous dates and flags ambiguous numeric dates", () => {
  assert.deepEqual(normalizeImportDate("2026-3-7"), { value: "2026-03-07" });
  assert.deepEqual(normalizeImportDate("13/4/2026"), { value: "2026-04-13" });
  assert.match(normalizeImportDate("4/5/26").warning ?? "", /Ambiguous date/);
});

test("roster review locks the school and infers separate ladder sizes", () => {
  const review = validateRosterRows([
    { school: "Wrong School", season: "2026", player_id: "B1", name: "Alex", gender: "boy", rank: "1", active: "1" },
    { school: "", season: "2026", player_id: "B2", name: "Blake", gender: "Boys", rank: "2", active: "1" },
    { school: "", season: "2026", player_id: "G1", name: "Casey", gender: "girl", rank: "1", active: "1" },
  ], "Home High");
  assert.equal(review.rows[0].school, "Home High");
  assert.equal(review.rows[0].ladder_size, "2");
  assert.equal(review.rows[2].ladder_size, "1");
  assert.equal(review.rows[2].gender, "Girls");
});

test("match review sorts chronologically and converts exact names to stable IDs", () => {
  const review = validateMatchRows([
    { date: "April 10, 2026", home_school: "Home High", opponent_school: "East", position: "BS2", home_player_1: "Blake", g1_home: "21", g1_opponent: "8", g2_home: "21", g2_opponent: "9" },
    { date: "April 2, 2026", home_school: "Home High", opponent_school: "West", position: "BS1", home_player_1: "B1", g1_home: "21", g1_opponent: "18", g2_home: "21", g2_opponent: "17" },
  ], "Home High", [
    { playerCode: "B1", displayName: "Alex", gender: "Boys" },
    { playerCode: "B2", displayName: "Blake", gender: "Boys" },
  ]);
  assert.equal(review.rows[0].date, "2026-04-02");
  assert.equal(review.rows[1].home_player_1, "B2");
});

