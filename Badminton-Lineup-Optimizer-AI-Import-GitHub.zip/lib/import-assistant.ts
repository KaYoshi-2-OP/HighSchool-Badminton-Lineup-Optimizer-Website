export const EVENT_ORDER = [
  "BS1", "BS2", "BS3", "BS4",
  "GS1", "GS2", "GS3", "GS4",
  "BD1", "BD2", "BD3",
  "GD1", "GD2", "GD3",
  "XD1", "XD2", "XD3",
] as const;

export type ImportKind = "roster" | "matches";
export type ImportRow = Record<string, string>;
export type ImportIssue = {
  rowIndex: number;
  field: string;
  value: string;
  reason: string;
  suggestions: string[];
};
export type ImportReview = {
  rows: ImportRow[];
  warnings: string[];
  unresolved: ImportIssue[];
  summary: string;
};
export type KnownPlayer = {
  playerCode: string;
  displayName: string;
  gender: "Boys" | "Girls";
};

export const ROSTER_COLUMNS = [
  "school", "season", "player_id", "name", "gender", "rank", "ladder_size", "active",
] as const;

export const MATCH_COLUMNS = [
  "date", "home_school", "opponent_school", "position", "home_player_1", "home_player_2",
  "g1_home", "g1_opponent", "g2_home", "g2_opponent", "g3_home", "g3_opponent",
] as const;

function clean(value: unknown) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

export function normalizeIdentity(value: unknown) {
  return clean(value).toLowerCase().replace(/[^a-z0-9]/g, "");
}

function validIso(year: number, month: number, day: number) {
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

export function normalizeImportDate(value: unknown): { value: string; warning?: string } {
  const source = clean(value);
  const iso = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(source);
  if (iso) {
    const year = Number(iso[1]);
    const month = Number(iso[2]);
    const day = Number(iso[3]);
    if (validIso(year, month, day)) return { value: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}` };
    return { value: source, warning: `Invalid calendar date: ${source}` };
  }

  const slash = /^(\d{1,2})[\/-](\d{1,2})[\/-](\d{2}|\d{4})$/.exec(source);
  if (slash) {
    const first = Number(slash[1]);
    const second = Number(slash[2]);
    const year = slash[3].length === 2 ? 2000 + Number(slash[3]) : Number(slash[3]);
    if (first <= 12 && second <= 12) {
      return { value: source, warning: `Ambiguous date "${source}". Replace it with YYYY-MM-DD.` };
    }
    const month = first > 12 ? second : first;
    const day = first > 12 ? first : second;
    if (validIso(year, month, day)) return { value: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}` };
  }

  const parsed = Date.parse(source);
  if (source && Number.isFinite(parsed) && /[A-Za-z]/.test(source)) {
    return { value: new Date(parsed).toISOString().slice(0, 10) };
  }
  return { value: source, warning: source ? `Unrecognized date "${source}". Use YYYY-MM-DD.` : "A match date is missing." };
}

function rowWithColumns(row: Record<string, unknown>, columns: readonly string[]) {
  return Object.fromEntries(columns.map((column) => [column, clean(row[column])])) as ImportRow;
}

function canonicalGender(value: string) {
  const normalized = value.toLowerCase();
  if (["b", "boy", "boys", "male", "m"].includes(normalized)) return "Boys";
  if (["g", "girl", "girls", "female", "f"].includes(normalized)) return "Girls";
  return value;
}

function canonicalPosition(value: string) {
  const compact = value.toUpperCase().replace(/[^A-Z0-9]/g, "");
  const aliases: Record<string, string> = {
    BOYSSINGLES1: "BS1", BOYSSINGLES2: "BS2", BOYSSINGLES3: "BS3", BOYSSINGLES4: "BS4",
    GIRLSSINGLES1: "GS1", GIRLSSINGLES2: "GS2", GIRLSSINGLES3: "GS3", GIRLSSINGLES4: "GS4",
    BOYSDOUBLES1: "BD1", BOYSDOUBLES2: "BD2", BOYSDOUBLES3: "BD3",
    GIRLSDOUBLES1: "GD1", GIRLSDOUBLES2: "GD2", GIRLSDOUBLES3: "GD3",
    MIXEDDOUBLES1: "XD1", MIXEDDOUBLES2: "XD2", MIXEDDOUBLES3: "XD3",
  };
  return aliases[compact] ?? compact;
}

export function validateRosterRows(rawRows: Array<Record<string, unknown>>, lockedHomeSchool?: string): ImportReview {
  const warnings: string[] = [];
  const unresolved: ImportIssue[] = [];
  const rows = rawRows.map((raw, index) => {
    const row = rowWithColumns(raw, ROSTER_COLUMNS);
    row.school = row.school || lockedHomeSchool || "";
    row.gender = canonicalGender(row.gender);
    row.active = row.active || "1";
    if (lockedHomeSchool && row.school && normalizeIdentity(row.school) !== normalizeIdentity(lockedHomeSchool)) {
      warnings.push(`Row ${index + 1}: school was changed to the locked home school, ${lockedHomeSchool}.`);
      row.school = lockedHomeSchool;
    }
    for (const field of ["school", "season", "player_id", "name", "gender", "rank"]) {
      if (!row[field]) unresolved.push({ rowIndex: index, field, value: "", reason: `${field} is required.`, suggestions: [] });
    }
    if (row.gender && !["Boys", "Girls"].includes(row.gender)) {
      unresolved.push({ rowIndex: index, field: "gender", value: row.gender, reason: "Gender must be Boys or Girls.", suggestions: ["Boys", "Girls"] });
    }
    if (row.season && (!Number.isInteger(Number(row.season)) || Number(row.season) < 1900)) {
      unresolved.push({ rowIndex: index, field: "season", value: row.season, reason: "Season must be a four-digit year.", suggestions: [] });
    }
    if (row.rank && (!Number.isInteger(Number(row.rank)) || Number(row.rank) < 1)) {
      unresolved.push({ rowIndex: index, field: "rank", value: row.rank, reason: "Rank must be a positive integer.", suggestions: [] });
    }
    return row;
  });

  const groups = new Map<string, ImportRow[]>();
  rows.forEach((row) => {
    const key = `${row.school}|${row.season}|${row.gender}`;
    groups.set(key, [...(groups.get(key) ?? []), row]);
  });
  for (const [key, group] of groups) {
    const inferred = Math.max(group.length, ...group.map((row) => Number(row.rank) || 0));
    group.forEach((row) => { if (!row.ladder_size) row.ladder_size = String(inferred); });
    const ranks = group.map((row) => Number(row.rank)).filter(Number.isFinite);
    const duplicates = [...new Set(ranks.filter((rank, index) => ranks.indexOf(rank) !== index))];
    if (duplicates.length) warnings.push(`${key}: duplicate rank${duplicates.length === 1 ? "" : "s"} ${duplicates.join(", ")}.`);
    const missing = Array.from({ length: inferred }, (_, index) => index + 1).filter((rank) => !ranks.includes(rank));
    if (missing.length) warnings.push(`${key}: skipped rank${missing.length === 1 ? "" : "s"} ${missing.join(", ")}.`);
  }
  const identities = new Set<string>();
  rows.forEach((row, index) => {
    const key = `${row.season}|${normalizeIdentity(row.player_id)}`;
    if (row.player_id && identities.has(key)) warnings.push(`Row ${index + 1}: player ID ${row.player_id} appears more than once in season ${row.season}.`);
    identities.add(key);
  });
  return { rows, warnings: [...new Set(warnings)], unresolved, summary: `${rows.length} roster row${rows.length === 1 ? "" : "s"} extracted for review.` };
}

function exactPlayer(value: string, knownPlayers: KnownPlayer[]) {
  const identity = normalizeIdentity(value);
  if (!identity) return { code: "", matches: [] as KnownPlayer[] };
  const byCode = knownPlayers.filter((player) => normalizeIdentity(player.playerCode) === identity);
  if (byCode.length === 1) return { code: byCode[0].playerCode, matches: byCode };
  const byName = knownPlayers.filter((player) => normalizeIdentity(player.displayName) === identity);
  return { code: byName.length === 1 ? byName[0].playerCode : "", matches: byName };
}

export function validateMatchRows(
  rawRows: Array<Record<string, unknown>>,
  lockedHomeSchool?: string,
  knownPlayers: KnownPlayer[] = [],
): ImportReview {
  const warnings: string[] = [];
  const unresolved: ImportIssue[] = [];
  const rows = rawRows.map((raw, index) => {
    const row = rowWithColumns(raw, MATCH_COLUMNS);
    row.position = canonicalPosition(row.position);
    row.home_school = row.home_school || lockedHomeSchool || "";
    if (lockedHomeSchool && row.home_school && normalizeIdentity(row.home_school) !== normalizeIdentity(lockedHomeSchool)) {
      warnings.push(`Row ${index + 1}: home school was changed to the locked home school, ${lockedHomeSchool}.`);
      row.home_school = lockedHomeSchool;
    }
    const date = normalizeImportDate(row.date);
    row.date = date.value;
    if (date.warning) unresolved.push({ rowIndex: index, field: "date", value: row.date, reason: date.warning, suggestions: [] });
    if (!EVENT_ORDER.includes(row.position as (typeof EVENT_ORDER)[number])) {
      unresolved.push({ rowIndex: index, field: "position", value: row.position, reason: "Position must be BS1–BS4, GS1–GS4, BD1–BD3, GD1–GD3, or XD1–XD3.", suggestions: [...EVENT_ORDER] });
    }
    for (const field of ["home_school", "opponent_school", "home_player_1"]) {
      if (!row[field]) unresolved.push({ rowIndex: index, field, value: "", reason: `${field} is required.`, suggestions: [] });
    }
    const pairEvent = /^(BD|GD|XD)/.test(row.position);
    if (pairEvent && !row.home_player_2) unresolved.push({ rowIndex: index, field: "home_player_2", value: "", reason: "A doubles event requires two home players.", suggestions: [] });
    if (!pairEvent) row.home_player_2 = "";
    for (const field of ["home_player_1", "home_player_2"] as const) {
      if (!row[field]) continue;
      const match = exactPlayer(row[field], knownPlayers);
      if (match.code) row[field] = match.code;
      else if (knownPlayers.length) {
        unresolved.push({
          rowIndex: index,
          field,
          value: row[field],
          reason: match.matches.length > 1 ? "This name matches multiple roster players." : "No exact player ID or roster name was found.",
          suggestions: match.matches.map((player) => `${player.playerCode} — ${player.displayName}`),
        });
      }
    }
    for (const game of [1, 2, 3]) {
      const home = row[`g${game}_home`];
      const opponent = row[`g${game}_opponent`];
      if ((home && !opponent) || (!home && opponent)) unresolved.push({ rowIndex: index, field: `g${game}`, value: `${home}-${opponent}`, reason: `Game ${game} needs both scores or neither score.`, suggestions: [] });
      if ([home, opponent].some((score) => score && (!Number.isInteger(Number(score)) || Number(score) < 0))) {
        unresolved.push({ rowIndex: index, field: `g${game}`, value: `${home}-${opponent}`, reason: "Scores must be nonnegative integers.", suggestions: [] });
      }
    }
    if (!row.g1_home || !row.g1_opponent || !row.g2_home || !row.g2_opponent) {
      unresolved.push({ rowIndex: index, field: "scores", value: "", reason: "Games 1 and 2 require complete scores.", suggestions: [] });
    }
    return row;
  });

  rows.sort((a, b) => a.date.localeCompare(b.date) || a.opponent_school.localeCompare(b.opponent_school) || EVENT_ORDER.indexOf(a.position as (typeof EVENT_ORDER)[number]) - EVENT_ORDER.indexOf(b.position as (typeof EVENT_ORDER)[number]));
  const groups = new Map<string, ImportRow[]>();
  rows.forEach((row) => {
    const key = `${row.date}|${row.opponent_school}`;
    groups.set(key, [...(groups.get(key) ?? []), row]);
  });
  for (const [key, group] of groups) {
    const positions = group.map((row) => row.position);
    const duplicates = [...new Set(positions.filter((position, index) => positions.indexOf(position) !== index))];
    if (duplicates.length) warnings.push(`${key}: duplicate event${duplicates.length === 1 ? "" : "s"} ${duplicates.join(", ")}.`);
    const missing = EVENT_ORDER.filter((position) => !positions.includes(position));
    if (missing.length) warnings.push(`${key}: incomplete dual meet; missing ${missing.join(", ")}. Historical imports may still be valid, but a true meet entry requires all 17 events.`);
  }
  return { rows, warnings: [...new Set(warnings)], unresolved, summary: `${rows.length} event row${rows.length === 1 ? "" : "s"} extracted across ${groups.size} meet${groups.size === 1 ? "" : "s"}, sorted chronologically.` };
}

export function validateImportRows(
  kind: ImportKind,
  rows: Array<Record<string, unknown>>,
  options: { lockedHomeSchool?: string; knownPlayers?: KnownPlayer[] } = {},
) {
  return kind === "roster"
    ? validateRosterRows(rows, options.lockedHomeSchool)
    : validateMatchRows(rows, options.lockedHomeSchool, options.knownPlayers);
}

