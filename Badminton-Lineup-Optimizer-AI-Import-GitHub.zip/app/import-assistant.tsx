"use client";

import { useMemo, useRef, useState } from "react";
import {
  MATCH_COLUMNS,
  ROSTER_COLUMNS,
  type ImportIssue,
  type ImportKind,
  type ImportReview,
} from "../lib/import-assistant";

type Props = {
  homeSchool: string;
  onImported: () => Promise<void> | void;
  onNotice: (notice: { tone: "success" | "error"; text: string }) => void;
};

const acceptedFiles = ".csv,.tsv,.txt,.xlsx,.xls,.pdf,image/png,image/jpeg,image/webp";

function fileAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("The selected file could not be read."));
    reader.readAsDataURL(file);
  });
}

function issueKey(issue: ImportIssue) {
  return `${issue.rowIndex}|${issue.field}`;
}

export default function ImportAssistant({ homeSchool, onImported, onNotice }: Props) {
  const [kind, setKind] = useState<ImportKind>("roster");
  const [sourceText, setSourceText] = useState("");
  const [sourceFile, setSourceFile] = useState<File | null>(null);
  const [review, setReview] = useState<ImportReview | null>(null);
  const [working, setWorking] = useState<"extract" | "import" | null>(null);
  const [resolved, setResolved] = useState<Set<string>>(new Set());
  const inputRef = useRef<HTMLInputElement>(null);
  const columns = kind === "roster" ? ROSTER_COLUMNS : MATCH_COLUMNS;
  const unresolved = useMemo(
    () => (review?.unresolved ?? []).filter((issue) => !resolved.has(issueKey(issue))),
    [review, resolved],
  );

  const switchKind = (next: ImportKind) => {
    setKind(next);
    setReview(null);
    setResolved(new Set());
  };

  const extract = async () => {
    setWorking("extract");
    setReview(null);
    setResolved(new Set());
    try {
      if (!sourceText.trim() && !sourceFile) throw new Error("Paste data or choose a source file first.");
      if (sourceFile && sourceFile.size > 10 * 1024 * 1024) throw new Error("The selected file is larger than 10 MB.");
      const file = sourceFile ? {
        name: sourceFile.name,
        mimeType: sourceFile.type || "application/octet-stream",
        dataUrl: await fileAsDataUrl(sourceFile),
      } : undefined;
      const response = await fetch("/api/ai-import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, text: sourceText, file }),
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error ?? "The source could not be extracted.");
      setReview(payload);
      onNotice({ tone: "success", text: "Extraction complete. Review and correct every highlighted item before importing." });
    } catch (error) {
      onNotice({ tone: "error", text: error instanceof Error ? error.message : "The source could not be extracted." });
    } finally {
      setWorking(null);
    }
  };

  const updateCell = (rowIndex: number, column: string, value: string) => {
    const nextRow = { ...(review?.rows[rowIndex] ?? {}), [column]: value };
    setReview((current) => current ? {
      ...current,
      rows: current.rows.map((row, index) => index === rowIndex ? nextRow : row),
    } : current);
    setResolved((current) => {
      const next = new Set(current);
      next.add(`${rowIndex}|${column}`);
      const game = /^(g[123])_/.exec(column)?.[1];
      if (game) {
        const home = nextRow[`${game}_home`];
        const opponent = nextRow[`${game}_opponent`];
        if ((!home && !opponent) || (home && opponent)) next.add(`${rowIndex}|${game}`);
      }
      if (nextRow.g1_home && nextRow.g1_opponent && nextRow.g2_home && nextRow.g2_opponent) next.add(`${rowIndex}|scores`);
      return next;
    });
  };

  const removeRow = (rowIndex: number) => {
    setReview((current) => current ? { ...current, rows: current.rows.filter((_, index) => index !== rowIndex) } : current);
    setResolved(new Set());
  };

  const importReviewedRows = async () => {
    if (!review?.rows.length) return;
    setWorking("import");
    try {
      const response = await fetch("/api/data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: kind === "roster" ? "import_rosters" : "import_matches", rows: review.rows }),
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error ?? "Import failed.");
      const summary = kind === "roster"
        ? `${payload.created} new players added; ${payload.continued} returning-player records preserved.`
        : `${payload.inserted} results added; ${payload.duplicates} duplicate rows safely skipped.`;
      onNotice({ tone: "success", text: `Reviewed data imported. ${summary}` });
      setReview(null);
      setSourceText("");
      setSourceFile(null);
      setResolved(new Set());
      await onImported();
    } catch (error) {
      onNotice({ tone: "error", text: error instanceof Error ? error.message : "Import failed." });
    } finally {
      setWorking(null);
    }
  };

  return (
    <div className="assistant-layout">
      <section className="panel assistant-source-panel">
        <div className="assistant-hero">
          <div className="assistant-spark" aria-hidden="true">✦</div>
          <div>
            <p className="eyebrow">AI-ASSISTED EXTRACTION · HUMAN-CONFIRMED IMPORT</p>
            <h2>Turn source files into clean badminton data</h2>
            <p>Upload a spreadsheet, PDF, screenshot, CSV, or pasted table. The assistant only extracts and classifies information. Dates, identities, required fields, Elo updates, and imports are checked by deterministic code.</p>
          </div>
        </div>
        <div className="assistant-kind-tabs" role="tablist" aria-label="Import type">
          <button role="tab" aria-selected={kind === "roster"} className={kind === "roster" ? "active" : ""} onClick={() => switchKind("roster")}>Seasonal roster</button>
          <button role="tab" aria-selected={kind === "matches"} className={kind === "matches" ? "active" : ""} onClick={() => switchKind("matches")}>Match results</button>
        </div>
        <div className="assistant-lock"><span>LOCKED HOME SCHOOL</span><strong>{homeSchool}</strong></div>
        <div className="source-grid">
          <label className="paste-source">
            <span>PASTE SOURCE DATA</span>
            <textarea value={sourceText} onChange={(event) => setSourceText(event.target.value)} placeholder={kind === "roster" ? "Paste names, ranks, gender, season, and IDs…" : "Paste dated match scores and the lineup that actually played…"}/>
          </label>
          <div className="file-source">
            <span>OR CHOOSE A FILE</span>
            <button className="file-drop" onClick={() => inputRef.current?.click()}>
              <b>{sourceFile ? sourceFile.name : "Choose spreadsheet, PDF, or image"}</b>
              <small>{sourceFile ? `${(sourceFile.size / 1024).toFixed(0)} KB selected` : "CSV · XLSX · PDF · PNG · JPG · max 10 MB"}</small>
            </button>
            {sourceFile && <button className="text-button" onClick={() => setSourceFile(null)}>Remove selected file</button>}
          </div>
        </div>
        <div className="assistant-actions">
          <p><strong>Privacy note:</strong> the selected source is sent to the configured extraction API with response storage disabled. Do not upload information your school is not permitted to process.</p>
          <button className="primary-button" disabled={working !== null || (!sourceText.trim() && !sourceFile)} onClick={() => void extract()}>{working === "extract" ? "Reading source…" : "Extract and Review"}</button>
        </div>
        <input ref={inputRef} hidden type="file" accept={acceptedFiles} onChange={(event) => { setSourceFile(event.target.files?.[0] ?? null); setReview(null); event.target.value = ""; }}/>
      </section>

      {review && (
        <section className="panel assistant-review-panel">
          <div className="panel-heading">
            <div><p className="eyebrow">REVIEW BEFORE IMPORT</p><h2>{review.summary}</h2></div>
            <span className={`review-status ${unresolved.length ? "needs-review" : "ready"}`}>{unresolved.length ? `${unresolved.length} item${unresolved.length === 1 ? "" : "s"} need review` : "Ready to import"}</span>
          </div>
          {(review.warnings.length > 0 || unresolved.length > 0) && (
            <div className="review-messages">
              {unresolved.map((issue) => <article className="blocking-issue" key={issueKey(issue)}><strong>Row {issue.rowIndex + 1} · {issue.field}</strong><span>{issue.reason}</span>{issue.suggestions.length > 0 && <small>Exact options: {issue.suggestions.join(", ")}</small>}</article>)}
              {review.warnings.map((warning) => <article key={warning}><strong>Check</strong><span>{warning}</span></article>)}
            </div>
          )}
          <p className="review-guidance">Edit any cell directly. A highlighted identity must use the exact permanent player ID shown on the Players page. Ambiguous dates must be changed to YYYY-MM-DD.</p>
          <div className="table-wrap assistant-table-wrap">
            <table className="assistant-table">
              <thead><tr><th>#</th>{columns.map((column) => <th key={column}>{column.replaceAll("_", " ")}</th>)}<th/></tr></thead>
              <tbody>{review.rows.map((row, rowIndex) => <tr key={rowIndex}><td>{rowIndex + 1}</td>{columns.map((column) => {
                const blocked = unresolved.some((issue) => issue.rowIndex === rowIndex && (
                  issue.field === column
                  || (issue.field === "scores" && /^g[12]_/.test(column))
                  || (/^g[123]$/.test(issue.field) && column.startsWith(`${issue.field}_`))
                ));
                return <td key={column}><input className={blocked ? "cell-needs-review" : ""} aria-label={`Row ${rowIndex + 1} ${column}`} value={row[column] ?? ""} onChange={(event) => updateCell(rowIndex, column, event.target.value)}/></td>;
              })}<td><button className="remove-row" aria-label={`Remove row ${rowIndex + 1}`} onClick={() => removeRow(rowIndex)}>×</button></td></tr>)}</tbody>
            </table>
          </div>
          <div className="assistant-actions review-actions">
            <p>{unresolved.length ? "Resolve or edit every highlighted item. The importer will run its own validation again." : `${review.rows.length} reviewed row${review.rows.length === 1 ? "" : "s"} will be sent to the existing deterministic importer.`}</p>
            <button className="primary-button" disabled={working !== null || unresolved.length > 0 || review.rows.length === 0} onClick={() => void importReviewedRows()}>{working === "import" ? "Importing and recalculating…" : "Import Reviewed Rows"}</button>
          </div>
        </section>
      )}
    </div>
  );
}
