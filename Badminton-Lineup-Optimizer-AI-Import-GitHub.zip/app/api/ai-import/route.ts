import {
  MATCH_COLUMNS,
  ROSTER_COLUMNS,
  type ImportKind,
  validateImportRows,
} from "../../../lib/import-assistant";

const MAX_FILE_BYTES = 10 * 1024 * 1024;

type RequestPayload = {
  kind?: ImportKind;
  text?: string;
  file?: { name?: string; mimeType?: string; dataUrl?: string };
};

function message(error: unknown) {
  return error instanceof Error ? error.message : "Unexpected error";
}

async function runtimeVariable(name: string) {
  if (process.env[name]) return process.env[name];
  try {
    const cloudflare = await import("cloudflare:workers");
    return (cloudflare.env as unknown as Record<string, string | undefined>)[name];
  } catch {
    return undefined;
  }
}

function schemaFor(kind: ImportKind) {
  const columns = kind === "roster" ? ROSTER_COLUMNS : MATCH_COLUMNS;
  return {
    type: "object",
    additionalProperties: false,
    properties: {
      rows: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          properties: Object.fromEntries(columns.map((column) => [column, { type: "string" }])),
          required: [...columns],
        },
      },
      warnings: { type: "array", items: { type: "string" } },
      summary: { type: "string" },
    },
    required: ["rows", "warnings", "summary"],
  };
}

function outputText(payload: Record<string, unknown>) {
  if (typeof payload.output_text === "string") return payload.output_text;
  const output = Array.isArray(payload.output) ? payload.output : [];
  for (const item of output) {
    if (!item || typeof item !== "object") continue;
    const content = Array.isArray((item as { content?: unknown[] }).content) ? (item as { content: unknown[] }).content : [];
    for (const part of content) {
      if (part && typeof part === "object" && (part as { type?: string }).type === "output_text" && typeof (part as { text?: unknown }).text === "string") {
        return (part as { text: string }).text;
      }
    }
  }
  return "";
}

function estimatedDataUrlBytes(dataUrl: string) {
  const encoded = dataUrl.split(",", 2)[1] ?? "";
  return Math.floor(encoded.length * 0.75);
}

function extractionInstructions(kind: ImportKind, homeSchool: string) {
  if (kind === "roster") {
    return `Extract a seasonal high-school badminton roster into exactly these columns: ${ROSTER_COLUMNS.join(", ")}.
The one locked home school is "${homeSchool}". Use it in every school field. Keep permanent player IDs when shown; never invent an identity. Use Boys or Girls for gender. Boys and girls have separate rank ladders. Use 1 for active unless the source clearly marks a player inactive. Leave any uncertain value as an empty string and explain it in warnings. Do not calculate Elo.`;
  }
  return `Extract high-school badminton event results into exactly these columns: ${MATCH_COLUMNS.join(", ")}.
The one locked home school is "${homeSchool}". One output row represents one event. Positions are BS1-BS4, GS1-GS4, BD1-BD3, GD1-GD3, and XD1-XD3. Preserve the lineup that actually played. Put the second home player only in doubles. Split each game into home and opponent scores. Normalize dates to YYYY-MM-DD only when unambiguous; otherwise preserve the original date and add a warning. Group information by date and opposing school. Never calculate Elo, winners, point differential, or ratings. Never guess an uncertain player identity—preserve the source spelling and warn.`;
}

export async function POST(request: Request) {
  try {
    const { assertSameOrigin, getAccountFromCookieHeader } = await import("../../../lib/auth");
    assertSameOrigin(request);
    const account = await getAccountFromCookieHeader(request.headers.get("cookie"));
    if (!account) return Response.json({ error: "Sign in to continue." }, { status: 401 });
    const apiKey = await runtimeVariable("OPENAI_API_KEY");
    if (!apiKey) {
      return Response.json({
        error: "AI import is not configured yet. Add OPENAI_API_KEY as a protected deployment secret; never place the key in browser code or commit it to GitHub.",
        code: "AI_NOT_CONFIGURED",
      }, { status: 503 });
    }

    const body = await request.json() as RequestPayload;
    const kind = body.kind;
    if (kind !== "roster" && kind !== "matches") return Response.json({ error: "Choose roster or match-results mode." }, { status: 400 });
    const sourceText = String(body.text ?? "").trim();
    const file = body.file;
    if (!sourceText && !file?.dataUrl) return Response.json({ error: "Paste data or choose a file first." }, { status: 400 });
    if (sourceText.length > 200_000) return Response.json({ error: "Pasted text is too large. Keep it under 200,000 characters." }, { status: 413 });
    if (file?.dataUrl && estimatedDataUrlBytes(file.dataUrl) > MAX_FILE_BYTES) {
      return Response.json({ error: "The selected file is larger than 10 MB. Split it into smaller files before extraction." }, { status: 413 });
    }

    const { getDashboard } = await import("../../../lib/server-store");
    const dashboard = await getDashboard(account);
    const homeSchool = dashboard.selectedHome.name;
    const knownPlayers = dashboard.players.map((player) => ({
      playerCode: player.playerCode,
      displayName: player.displayName,
      gender: player.gender,
    }));
    const userContent: Array<Record<string, string>> = [];
    if (file?.dataUrl) {
      if (String(file.mimeType ?? "").startsWith("image/")) {
        userContent.push({ type: "input_image", image_url: file.dataUrl });
      } else {
        userContent.push({
          type: "input_file",
          filename: String(file.name || "import-file"),
          file_data: file.dataUrl,
        });
      }
    }
    userContent.push({
      type: "input_text",
      text: `${extractionInstructions(kind, homeSchool)}\n\nAdditional pasted source:\n${sourceText || "(none)"}`,
    });

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: await runtimeVariable("OPENAI_IMPORT_MODEL") || "gpt-5.4-nano",
        store: false,
        input: [{ role: "user", content: userContent }],
        text: {
          format: {
            type: "json_schema",
            name: `${kind}_badminton_import`,
            strict: true,
            schema: schemaFor(kind),
          },
        },
        max_output_tokens: 16000,
      }),
    });
    const openAiPayload = await response.json() as Record<string, unknown>;
    if (!response.ok) {
      const apiMessage = (openAiPayload.error as { message?: string } | undefined)?.message;
      throw new Error(apiMessage || "The AI extraction service could not read this source.");
    }
    const text = outputText(openAiPayload);
    if (!text) throw new Error("The extraction service returned no structured rows.");
    const extracted = JSON.parse(text) as { rows?: Array<Record<string, unknown>>; warnings?: string[]; summary?: string };
    const review = validateImportRows(kind, extracted.rows ?? [], { lockedHomeSchool: homeSchool, knownPlayers });
    review.warnings = [...new Set([...(extracted.warnings ?? []), ...review.warnings])];
    if (extracted.summary) review.summary = `${extracted.summary} ${review.summary}`.trim();
    return Response.json(review);
  } catch (error) {
    return Response.json({ error: message(error) }, { status: 400 });
  }
}
